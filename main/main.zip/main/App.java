// Ensin luokan määrittely
public class App {
    /* Sitten main-operaatio eli pääohjelma,
     * joka määritetään aina samalla tavalla.
     * Tähän pääoperaatioon siis kuuluu otsikko ja runko */
    public static void main(String args[]) {
        // Tulostus
        System.out.println("Hello World!");
    }    
}
// ohjelma toimii mikä on aika kiva
